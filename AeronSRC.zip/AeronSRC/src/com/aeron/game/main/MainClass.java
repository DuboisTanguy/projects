package com.aeron.game.main;

import javax.swing.JOptionPane;

import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.SlickException;

public class MainClass {
	
	public static void main(String[] args) throws SlickException{
		//JOptionPane.showMessageDialog(null, "Welcome to the Aeron Project app", "AERON", JOptionPane.INFORMATION_MESSAGE);
		new AppGameContainer(new WindowGame(), 750, 500, false).start();
	}
	
}
