package com.aeron.game.events;

import org.newdawn.slick.tiled.TiledMap;

import com.aeron.game.main.WindowGame;

public class Triggers {

	private TiledMap map;
	private WindowGame wg;
	
	public Triggers(TiledMap map, WindowGame g){
		this.wg = g;
		this.map = map;
	}
	
	public void update(float x, float y){
		for(int objectID = 0 ; objectID<map.getObjectCount(0) ; objectID++){
			if(isInTrigger(objectID, x, y)){
				if(this.map.getObjectType(0, objectID).equals("teleport")){
					wg.teleport(objectID);
				}
			}
		}
	}
	
	private boolean isInTrigger(int id, float x, float y){
		return (
				x>map.getObjectX(0, id) &&
				x<map.getObjectX(0, id)+map.getObjectWidth(0, id)&&
				y>map.getObjectY(0, id) &&
				y<map.getObjectY(0, id)+map.getObjectHeight(0, id)
				);
	}
	
}
