package com.aeron.game.main;

import java.util.HashMap;

import org.newdawn.slick.Animation;
import org.newdawn.slick.BasicGame;
import org.newdawn.slick.Color;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Image;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.SpriteSheet;
import org.newdawn.slick.tiled.TiledMap;

import com.aeron.game.events.Triggers;

public class WindowGame extends BasicGame{
	
	OpacityRunnable or = new OpacityRunnable(this);
	private int gemsToFind = 1;
	private int gemsFound = 0;
	private int opacity = 0;
	private boolean isPrinting = false;
	private String textToPrint = "";
	private int startX = 666, startY = 666;
	private GameContainer container;
	private TiledMap map;
	private float x = startX , y = startY;
	private float xCamera = x, yCamera = y;
	private int direction = 2;
	private boolean moving = false;
	private Animation[] animations = new Animation[8];
	private boolean up = false, down = false, left = false, right = false;
	private Triggers trig;
	private HashMap<String,Boolean> hm = new HashMap<String,Boolean>();
	
	public WindowGame(){
		super("AERON :: 1.0");
	}

	@Override
	public void init(GameContainer container) throws SlickException {
		container.setShowFPS(false);
		this.container = container;
		this.map = new TiledMap("main/resources/map/MAP.tmx");
		this.trig = new Triggers(map, this);
		SpriteSheet ss = new SpriteSheet("main/resources/sprites/SKELETON.png",64,64);
		this.animations[0] = loadAnimation(ss, 0, 1, 0);
		this.animations[1] = loadAnimation(ss, 0, 1, 1);
		this.animations[2] = loadAnimation(ss, 0, 1, 2);
		this.animations[3] = loadAnimation(ss, 0, 1, 3);
		this.animations[4] = loadAnimation(ss, 1, 9, 0);
		this.animations[5] = loadAnimation(ss, 1, 9, 1);
		this.animations[6] = loadAnimation(ss, 1, 9, 2);
		this.animations[7] = loadAnimation(ss, 1, 9, 3);
		this.x = startX;
		this.y = startY;
		this.setToPrint("Find all the objects !");
		initHm();
	}
	
	@Override
	public void render(GameContainer container, Graphics g) throws SlickException {
		g.translate(container.getWidth()/2-(int)this.xCamera, container.getHeight()/2-(int)this.yCamera);
		this.map.render(0, 0, 0);
		this.map.render(0, 0, 1);
		for(int i=1;i<=gemsToFind;i++){
			if(hm.get("GEM"+i))this.map.render(0, 0, this.map.getLayerIndex("GEM"+1));
		}
		this.renderCharacter(g);
		this.map.render(0, 0, 2);
		if(isPrinting)
			Printer.printText(g, ((int)x)-(container.getWidth()/2), ((int)y)-(container.getHeight()/2)-10, textToPrint, opacity);
	}
	
	@Override
	public void update(GameContainer container, int delta) throws SlickException {
		trig.update(x, y);
		if(moving){
			float futurX = this.getFuturX(delta);
			float futurY = this.getFuturY(delta);
			if(isCollision(futurX,futurY))
				moving = false;
			else{
				this.x=futurX;
				this.y=futurY;
			}
		}
		this.processCameraCoordinates();
	}
	
	@Override
	public void keyPressed(int key, char c){
		if(key==Input.KEY_Z||key==Input.KEY_S||key==Input.KEY_Q||key==Input.KEY_D)
			updateMovingAnimation(true,key);
	}
	
	@Override
	public void keyReleased(int key, char c){
		updateMovingAnimation(false,key);
		if(Input.KEY_ESCAPE==key)
			container.exit();
	}
	
	public static Animation loadAnimation(SpriteSheet ss, int startX, int endX, int y){
		Animation anim = new Animation();
		for(int x = startX ; x < endX ; x++ )
			anim.addFrame(ss.getSprite(x, y), 100);
		return anim;
	}
	
	public void renderCharacter(Graphics g){
		g.setColor(new Color(0,0,0, .5f));
		g.fillOval((int)x-16, (int)y-10, 32, 16);
		g.drawAnimation(animations[direction + ((moving)?4:0)], (int)x-32, (int)y-64);
	}

	public void updateMovingAnimation(boolean b, int key){
		int d = 2;
		switch(key){
		case Input.KEY_Z: up=b; if(b)d=0; break;
		case Input.KEY_S: down=b; if(b)d=2; break;
		case Input.KEY_Q: left=b; if(b)d=1; break;
		case Input.KEY_D: right=b; if(b)d=3; break;
		}
		moving = (up||down||right||left)?true:false;
		if(!b&&moving)
			direction = getActiveKeyDirection();
		if(moving && b)
			direction = d;
	}
	
	public int getActiveKeyDirection(){
		return (
				(up)?0:
					(down)?2:
						(left)?1:
							(right)?3:2
				);
	}
	
	public float getFuturX(int delta){
		float futurX = x;
		if(left)
			futurX = this.x - .1f*delta;
		if(right)
			futurX = this.x + .1f*delta;
		return futurX;
	}
	
	public float getFuturY(int delta){
		float futurY = y;
		if(up)
			futurY = this.y - .1f*delta;
		if(down)
			futurY = this.y + .1f*delta;
		return futurY;
	}
	
	public boolean isCollision(float x, float y){
		int tileW = this.map.getTileWidth();
		int tileH = this.map.getTileHeight();
		int logiclayer = this.map.getLayerIndex("logic");
		Image tile = this.map.getTileImage((int)x/tileW, (int)y/tileH, logiclayer);
		boolean collision = tile!=null;
		if(collision){
			Color color = tile.getColor((int) x % tileW, (int) y % tileH);
	        collision = color.getAlpha() > 0;
		}
		return collision;
	}
	
	public void teleport(int id){
		this.x = Float.parseFloat( this.map.getObjectProperty(0, id, "dest-x", Float.toString(this.x)) );
		this.y = Float.parseFloat( this.map.getObjectProperty(0, id, "dest-y", Float.toString(this.y)) );
	}
	
	public void changeMap(int id) {
		if(gemsFound>=gemsToFind){
			try {
				this.map = new TiledMap(
						"main/resources/map/" + (this.map.getObjectProperty(0, id, "mapName", "MAP")) + ".tmx");
				String lvlName = this.map.getObjectProperty(0, id, "levelName", "Level 1");
				this.gemsToFind = Integer.parseInt(this.map.getObjectProperty(0, id, "nbGems", "1"));
				this.gemsFound = 0;
				this.x=startX;
				this.y=startY;
				this.setToPrint(lvlName);
			} catch (SlickException e) {
				e.printStackTrace();
			}
			this.x=this.startX;
			this.y=this.startY;
			initHm();
		}
	}
	
	public void foundRsrc(int id){
		String layer = this.map.getObjectProperty(0, id, "calque", "GEM1");
		if(hm.get(layer)){
			hm.put(this.map.getObjectProperty(0, id, "calque", "GEM1"), false);
			gemsFound++;
			setToPrint(gemsFound+"/"+gemsToFind);
		}
	}
	
	public void processCameraCoordinates(){
		xCamera = (x-this.container.getWidth()/2>0)? ((container.getWidth()/2+(int)this.x)<(map.getTileWidth()*map.getWidth()))?x:xCamera :xCamera;
		yCamera = (y-this.container.getHeight()/2>0)? ((container.getHeight()/2+(int)this.y)<(map.getTileHeight()*map.getHeight()))?y:yCamera :yCamera;
	}
	
	public void setOpacity(int opacity) {
		this.opacity = opacity;
	}

	public void setPrinting(boolean isPrinting) {
		this.isPrinting = isPrinting;
	}

	public void startOpacityCooldown(){
		if(or.isRunning())or.setRunning(false);
		or = new OpacityRunnable(this);
		Thread t = new Thread(or);
		t.start();
	}
	
	public void setToPrint(String st){
		this.textToPrint=st;
		this.isPrinting=true;
		this.startOpacityCooldown();
	}
	
	public void initHm(){
		for(int i=1;i<=gemsToFind;i++){
			hm.put("GEM"+i, true);
		}
	}
	
}
