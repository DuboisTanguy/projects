package com.aeron.game.main;

public class OpacityRunnable implements Runnable {
	
	private WindowGame wg;
	private int time = 255;
	private int incr = 10;
	private int timeSleeping = 99;
	private int interTime = 1000;
	private boolean running = false;
	
	public OpacityRunnable(WindowGame w){
		this.wg = w;
	}
	
	@Override
	public void run() {
		running = true;
		for (int i = 0; i < time; i += incr) {
			if(!running)return;
			wg.setOpacity(i);
			try {
				Thread.sleep(timeSleeping);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		try {
			Thread.sleep(interTime);
		} catch (InterruptedException e1) {
			e1.printStackTrace();
		}
		for (int i = time; i > 0; i -= incr) {
			if(!running)return;
			wg.setOpacity(i);
			try {
				Thread.sleep(timeSleeping);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		wg.setPrinting(false);
		running = false;
	}

	public boolean isRunning() {
		return running;
	}
	
	public void setRunning(boolean b){
		running = b;
	}

}
