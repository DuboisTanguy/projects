package com.aeron.game.main;

import java.awt.Font;

import org.newdawn.slick.Color;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.TrueTypeFont;


public class Printer {
	
	public Printer(){
		//
	}
	
	public static void printText(Graphics g, int x, int y, String str, int opacity){
		Color c = new Color(255, 255, 255, opacity);
		g.setColor(c);
		TrueTypeFont test = new TrueTypeFont(new Font(Font.DIALOG, Font.BOLD , 50),true);
		g.setFont(test);
		g.drawString(str, x, y);
	}
	
}
