package com.aeron.game.main;

import org.newdawn.slick.AppGameContainer;
import org.newdawn.slick.SlickException;

public class MainClass {
	
	public static void main(String[] args) throws SlickException{
		new AppGameContainer(new WindowGame(), 750, 500, false).start();
	}
	
}
